﻿using Microsoft.EntityFrameworkCore;
using WebAppTask.Models;

namespace WebAppTask.AppDbContext
{
    public class WebAppTaskDbContext:DbContext
    {
        public WebAppTaskDbContext(DbContextOptions<WebAppTaskDbContext> options):base(options)
        {
        }
        public DbSet<Product> Products { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<ProductCategory> ProductCategories { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<ProductCategory>().HasKey(pc=> new {pc.ProductID, pc.CategoryID});
            modelBuilder.Entity<ProductCategory>().HasOne(pc => pc.Product).WithMany(p => p.ProductCategories).HasForeignKey(pc=> pc.ProductID);
            modelBuilder.Entity<ProductCategory>().HasOne(pc => pc.Category).WithMany(c => c.ProductCategories).HasForeignKey(pc => pc.CategoryID);
        }
    }
}
