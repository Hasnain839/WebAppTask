﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace WebAppTask.Migrations
{
    public partial class suk : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
