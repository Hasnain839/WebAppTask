﻿using System.ComponentModel.DataAnnotations;

namespace WebAppTask.Models
{
    public class Category
    {
        
        public int CategoryID { get; set; }
        [Required]
        public string CategoryName { get; set; }
        public ICollection<ProductCategory> ProductCategories { get; set; }=new List<ProductCategory>();
    }
}
