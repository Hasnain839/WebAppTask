﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WebAppTask.AppDbContext;
using WebAppTask.Models;

namespace WebAppTask.Controllers
{
    public class ProductsController : Controller
    {
        private readonly WebAppTaskDbContext _context;
        public ProductsController(WebAppTaskDbContext context)
        {
            _context = context;
        }
        public async Task<IActionResult> Index()
        {
            var products = await _context.Products.Include(p => p.ProductCategories).ThenInclude(pc => pc.Category).ToListAsync();
            return View(products);
            
        }

       
        public IActionResult Create()
        {
            //ViewData["Categories"] = new SelectList(_context.Categories, "CategoryID", "CategoryName");
            ViewBag.Categories = new SelectList(_context.Categories, "CategoryID", "CategoryName");
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Product product, int[] selectedCategories)
        {
            if (ModelState.IsValid)
            {
                _context.Add(product);
                await _context.SaveChangesAsync();
                foreach (var categoryId in selectedCategories)
                {
                    var productCategory = new ProductCategory()
                    {
                        ProductID = product.ProductID,
                        CategoryID = categoryId,
                    };
                    _context.ProductCategories.Add(productCategory);
                }
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["Categories"] = new SelectList(_context.Categories, "CategoryID", "CategoryName");
            return View(product);
        }

        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Products == null)
            {
                return NotFound();
            }
            var product = await _context.Products.Include(p => p.ProductCategories).ThenInclude(pc => pc.Category).FirstOrDefaultAsync(m => m.ProductID == id);
            if (product == null)
            {
                return NotFound();
            }
            var selectedCategories = product.ProductCategories.Select(pc => pc.CategoryID).ToList();
            ViewBag.Categories = new MultiSelectList(_context.Categories, "CategoryID", "CategoryName", selectedCategories);
            return View(product);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, [Bind("ProductID,ProductName,Price,Quantity,Tags")] Product product)
        {
            if (id != product.ProductID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(product);
                    _context.SaveChanges();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ProductExists(product.ProductID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(product);
        }

        private bool ProductExists(int id)
        {
            return _context.Products.Any(e => e.ProductID == id);
        }


        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public async Task<IActionResult> Edit(int id, Product product, int[] selectedCategories)
        //{
        //    if (id != product.ProductID)
        //    {
        //        return NotFound();
        //    }
        //    if (ModelState.IsValid)
        //    {
        //        try
        //        {
        //            _context.Update(product);
        //            await _context.SaveChangesAsync();
        //            var existingCategories = _context.ProductCategories.Where(pc => pc.ProductID == product.ProductID);
        //            _context.ProductCategories.RemoveRange(existingCategories);

        //            foreach (var categoryId in selectedCategories)
        //            {
        //                var productCategory = new ProductCategory
        //                {
        //                    ProductID = product.ProductID,
        //                    CategoryID = categoryId,
        //                };
        //                _context.ProductCategories.Add(productCategory);
        //            }
        //            await _context.SaveChangesAsync();
        //        }
        //        catch (DbUpdateConcurrencyException)
        //        {
        //            if (!ProductExists(product.ProductID))
        //            {
        //                return NotFound();
        //            }
        //            else { throw; }
        //        }
        //        return RedirectToAction(nameof(Index));
        //    }

        //    var selectedCategoriesList = product.ProductCategories.Select(pc => pc.CategoryID).ToList();
        //    ViewBag.Categories = new MultiSelectList(_context.Categories, "CategoryID", "CategoryName", selectedCategoriesList);
        //    return View(product);


        //}
        //private bool ProductExists(int id)
        //{
        //    return _context.Products.Any(e => e.ProductID == id);
        //}




        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var product = _context.Products.FirstOrDefault(m => m.ProductID == id);
            if (product == null)
            {
                return NotFound();
            }

            return View(product);

            //if(id==null || _context.Products == null)
            //{
            //    return NotFound();
            //}
            //var product= await _context.Products.Include(p=>p.ProductCategories).ThenInclude(pc=>pc.Category).FirstOrDefaultAsync(m=>m.ProductID==id);
            //if (product == null)
            //{
            //    return NotFound();
            //}
            //return View(product);
        }
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        //[HttpPost]
        public IActionResult Delete(int id)
        {
            var product = _context.Products.Find(id);
            if (product == null)
            {
                return NotFound();
            }
            _context.Products.Remove(product);
            _context.SaveChanges();
            return RedirectToAction(nameof(Index));

            //var product = _context.Products.Find(id);
            //if (product == null)
            //{
            //    return NotFound();
            //}

            //_context.Products.Remove(product);
            //_context.SaveChanges();
            //return RedirectToAction(nameof(Index));
        }
        //public async Task<IActionResult> DeleteConfirmed(int id)
        //{
        //    var product = _context.Products.Find(id);
        //    _context.Products.Remove(product);
        //    _context.SaveChanges();
        //    return RedirectToAction(nameof(Index));


        //    if (_context.Products == null)
        //    {
        //        return Problem("Entity set 'WebAppTaskDbContext.Products' is null");
        //    }
        //    var product = await _context.Products.FindAsync(id);
        //    if (product != null)
        //    {
        //        var productCategories = _context.ProductCategories.Where(pc => pc.ProductID == id);
        //        _context.ProductCategories.RemoveRange(productCategories);
        //        _context.Products.Remove(product);
        //    }
        //    await _context.SaveChangesAsync();
        //    return RedirectToAction(nameof(Index));

    }
}